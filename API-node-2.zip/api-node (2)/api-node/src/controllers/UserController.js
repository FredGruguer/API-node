

const express = require('express');
const userService = require('../services/UserService');
const UserService = require('../services/UserService');

const router = express.Router();

router.get('/', async(req, res) => {
    try{
        const user = userService.getAll();
        res.json(user);
    }catch(err){
        console.log(err);
        res.status(400).json({error: err.message});
    }
});

router.post('/', async(req, res) => {
    const {username, password} = req.body;
    const user = await userService.register(username, password);
    res.json(user);
    
});



router.delete('/:username', authencicateToken, async (req, res) =>{
    try{
        const {username} = req.params;
        await UserService.delete(username);
        res.send(200);
    }catch(error){
        res.status(400).json({error: err.message});
    }
})

module.exports = router