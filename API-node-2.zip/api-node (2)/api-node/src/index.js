const express = require('express');
const UserController = require('./controllers/UserController');

const app = express();
app.use(express.json());
app.use('/api/users', UserController);

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000 (não é mais que 8000)')
});